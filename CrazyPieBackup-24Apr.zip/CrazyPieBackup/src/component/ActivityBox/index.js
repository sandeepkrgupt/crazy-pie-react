import React, { useState } from 'react';
import { Card, Row, Col } from 'antd';
import { TwitterOutlined, QqOutlined, InstagramOutlined, TeamOutlined } from '@ant-design/icons';

const ActivityBox = () => {
    const [text, newText] = useState('Text');
    return (
        <>
            <Row className="activity-box">
                <Col span={4} xs={2} />
                <Col span={16} xs={20}>
                    <Card> {/* title="Card Title" */}
                        <Card.Grid className="activity-box-event-tab" onClick={() => newText(console.log(text))}>
                            <h1>Events</h1>
                            <TwitterOutlined />
                            <p>hello Event</p>
                        </Card.Grid>
                        <Card.Grid className="activity-box-newarrival-tab" onClick={() => newText(console.log(text))}>
                            <h1>New Arrivals</h1>
                            <QqOutlined />
                            <p>hello New Arrivals</p>
                        </Card.Grid>
                    </Card>
                    <Card>
                        <Card.Grid className="activity-box-popularpost-tab" onClick={() => newText(console.log(text))}>
                            <h1>Popular Posts</h1>
                            <InstagramOutlined />
                            <p>Hello Popular Posts</p>
                        </Card.Grid>
                        <Card.Grid className="activity-box-popularpeople-tab" onClick={() => newText(console.log(text))}>
                            <h1>Popular People</h1>
                            <TeamOutlined />
                            <p>hello Popular People</p>
                        </Card.Grid>
                    </Card>
                </Col>
                <Col span={4} xs={2} />
            </Row>
        </>
    );
};

export default ActivityBox;
