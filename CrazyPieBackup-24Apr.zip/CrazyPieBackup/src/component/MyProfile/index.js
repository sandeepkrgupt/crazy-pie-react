import React from 'react';
import { Row, Col, Form, Input, PageHeader } from 'antd';
import ProfileImage from './profileImage';

const MyProfile = () => {
    return (
        <>
            <Row className="my-profile">
                <Col span={2} />
                <Col span={20}>
                    <PageHeader title="Profile" />
                    <Row>
                        <Col span={6}>
                            <ProfileImage />
                        </Col>
                        <Col span={12}>
                            <Form.Item
                                name="name"
                                label="Name"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your nickname!',
                                        whitespace: true
                                    }
                                ]}
                            >
                                <Input placeholder="Sandeep Kumar" />
                            </Form.Item>
                            <Form.Item
                                name="password"
                                label="Password"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your password!'
                                    }
                                ]}
                            //hasFeedback
                            >
                                <Input.Password placeholder="*******" />
                            </Form.Item>
                            <Form.Item
                                name="passion"
                                label="Passion"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your passion!',
                                        whitespace: true
                                    }
                                ]}
                            >
                                <Input placeholder="Singing" />
                            </Form.Item>
                            <Form.Item
                                name="profession"
                                label="Profession"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your profession!',
                                        whitespace: true
                                    }
                                ]}
                            >
                                <Input placeholder="Engineer" />
                            </Form.Item>
                        </Col>
                    </Row>
                </Col>
                <Col span={2} />
            </Row>
        </>
    );
};

export default MyProfile;
