import React from 'react';
import { Drawer } from 'antd';

const RightDrawer = (props) => {
    return (
        <div>
            <Drawer
                title={props.title}
                placement="right"
                closable={false}
                onClose={() => props.showDrawer(false)}
                visible={props.visible}
            >
                <p>Some contents...</p>
                <p>Some contents...</p>
                <p>Some contents...</p>
            </Drawer>
        </div>
    );
};

export default RightDrawer;
