import React, { useState } from 'react';
import { Row, Col, Badge } from 'antd';
import { BellOutlined } from '@ant-design/icons';
import RightDrawer from '../RightDrawer';

const Notification = () => {
    const [visible = false, showDrawer, title = 'Notifications'] = useState();
    return (
        <>
            <Row className="notification-tab">
                <Col>
                    <Badge className="site-badge-count-109" count={1} style={{ backgroundColor: '#52c41a' }} />
                    <BellOutlined onClick={() => showDrawer(true)} />
                </Col>
            </Row>
            <RightDrawer title={title} visible={visible} showDrawer={showDrawer} />
        </>
    );
};

export default Notification;
