import React from 'react';
import { Card } from 'antd';

const { Meta } = Card;
const UserSuggestionCard = (props) => {
    const {
        alt,
        src,
        title,
        description
    } = props;
    return (
        <Card
            hoverable
            style={{ width: '12vw', margin: '2%' }}
            cover={<img alt={alt} src={src} />}
        >
            <Meta title={title} description={description} />
        </Card>
    );
};

export default UserSuggestionCard;
