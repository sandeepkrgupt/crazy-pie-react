import React from 'react';
import UserSuggestionCard from '../UserSuggestionCard';
import { Row, Button, Col } from 'antd';

const UserSuggestionBox = (props) => {
    const allUsers = props.details.map((p) => <UserSuggestionCard key={props.details.id} {...p} />);
    return (
        <>
            <Row className="user-suggestion-cards">
                {allUsers}
                <Col span={24}>
                    <Button type="primary" className="btn-prev-card">Previous Suggestion</Button>
                    <Button type="primary" className="btn-next-card">Next Suggestion</Button>
                </Col>
            </Row>
        </>
    );
};

export default UserSuggestionBox;
