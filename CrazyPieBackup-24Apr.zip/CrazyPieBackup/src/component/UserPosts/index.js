import React from 'react';
import { Row, Col } from 'antd';
import UserPostCard from './PostCard';

const UserPostBox = (props) => {
    return (
        <Row>
            <Col span={6} xs={4} />
            <Col span={12} xs={16}>
                <UserPostCard />
            </Col>
            <Col span={6} xs={4} />
        </Row>
    );
};

export default UserPostBox;

