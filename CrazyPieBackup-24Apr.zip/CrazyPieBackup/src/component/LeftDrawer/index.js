import React from 'react';
import { Drawer } from 'antd';

const LeftDrawer = (props) => {
    return (
        <div>
            <Drawer
                title={props.title}
                placement="left"
                closable={false}
                onClose={() => props.showDrawer(false)}
                visible={props.visible}
            >
                <p>Some contents...</p>
                <p>Some contents...</p>
                <p>Some contents...</p>
            </Drawer>
        </div>
    );
};

export default LeftDrawer;

