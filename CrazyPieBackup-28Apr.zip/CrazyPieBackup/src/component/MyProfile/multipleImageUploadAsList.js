import React, { useState } from 'react';
import { Upload, Button } from 'antd';
import { UploadOutlined } from '@ant-design/icons';

const fileList = [];

const props = {
    action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
    listType: 'picture',
    defaultFileList: [...fileList]
};

const MultipleImageUploadAsList = () => {
    const [imageCount, disableUpload] = useState(0);
    return (
        <>
            <Upload {...props}>
                <Button onClick={() => disableUpload(imageCount + 1)} disabled={imageCount === 2}>
                    <UploadOutlined /> `You Can Upload {2 - imageCount} More`
                </Button>
            </Upload>
        </>
    );
};

export default MultipleImageUploadAsList;
