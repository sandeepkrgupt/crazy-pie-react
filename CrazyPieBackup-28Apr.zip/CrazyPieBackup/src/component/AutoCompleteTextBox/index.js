import React, { useState } from 'react';
import { AutoComplete, Input } from 'antd';

const AutoCompleteResult = () => {
    const [options, setOptions] = useState([]);

    const handleSearch = value => {
        setOptions(!value ? [] : [{
            value: 'Tom Dimero'
        },
        {
            value: 'Jenifer Lok'
        },
        {
            value: 'Kett Winsen'
        }]
        );
    };

    const handleKeyPress = ev => {
        console.log('handleKeyPress', ev);
    };

    const onSelect = value => {
        console.log('onSelect', value);
    };

    return (
        <AutoComplete
            options={options}
            filterOption={(inputValue, option) =>
                option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
            }
            onSelect={onSelect}
            onSearch={handleSearch}
        >
            <Input
                placeholder="Search here"
                className="custom"
                onKeyPress={handleKeyPress}
            />
        </AutoComplete>
    );
};

export default AutoCompleteResult;
