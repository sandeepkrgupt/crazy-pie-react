import React from 'react';
import { Row, Col, PageHeader, Form, Input, Button, Tooltip } from 'antd';
import { QuestionCircleOutlined } from '@ant-design/icons';
import TextArea from 'antd/lib/input/TextArea';
import moment from 'moment';
import AutoCompleteResult from '../AutoCompleteTextBox';
import AutoCompleteSelectResult from '../AutoCompleteSelectBox';

const CreateGroup = () => {
    const [form] = Form.useForm();
    const onFinish = values => {
        const groupCreationDate = moment.now();
        console.log('Group id is =', values.groupname + '_' + groupCreationDate);
    };
    return (
        <Row className="create-group">
            <Col span={2} />
            <Col span={20}>
                <Form
                    form={form}
                    name="register"
                    onFinish={onFinish}
                    //initialValues={{ email: 'abc.com' }}
                    scrollToFirstError
                >
                    <PageHeader title="Create A Group" />
                    <Row>
                        <Col span={24}>
                            <Form.Item
                                name="groupname"
                                label="Group Name"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your group name!',
                                        whitespace: true
                                    }
                                ]}
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                name="group_type"
                                label="Group Type"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input your group type!',
                                        whitespace: true
                                    }
                                ]}
                            >
                                <AutoCompleteSelectResult />
                            </Form.Item>
                            <Form.Item
                                name="slogan"
                                label="Slogan"
                            >
                                <Input />
                            </Form.Item>
                            <Form.Item
                                name="details"
                                label="Details"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please input group details!',
                                        whitespace: true
                                    }
                                ]}
                            >
                                <TextArea rows={4} />
                            </Form.Item>
                            <Form.Item
                                name="addmembers"
                                label={
                                    <span>
                                        Add Members&nbsp;
                                        <Tooltip title="Use member_id to search">
                                            <QuestionCircleOutlined />
                                        </Tooltip>
                                    </span>
                                }
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please add your group members!',
                                        whitespace: true
                                    }
                                ]}
                            >
                                <AutoCompleteResult />
                            </Form.Item>
                            <Form.Item>
                                <Button type="primary" htmlType="submit">
                                    Create Group
                                </Button>
                            </Form.Item>
                        </Col>
                    </Row>
                </Form>
            </Col>
            <Col span={2} />
        </Row>
    );
};

export default CreateGroup;
