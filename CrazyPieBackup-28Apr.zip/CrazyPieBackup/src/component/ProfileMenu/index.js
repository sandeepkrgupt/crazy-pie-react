import React, { useState } from 'react';
import { Row, Col } from 'antd';
import { UserOutlined } from '@ant-design/icons';
import RightDrawer from '../RightDrawer';

const ProfileMenu = () => {
    const [visible = false, showDrawer, title = 'Profile'] = useState();
    return (
        <>
            <Row className="user-profilemenu-tab">
                <Col>
                    <UserOutlined onClick={() => showDrawer(true)} />
                    <span>Mah</span>
                </Col>
            </Row>
            <RightDrawer title={title} visible={visible} showDrawer={showDrawer} />
        </>
    );
};

export default ProfileMenu;
