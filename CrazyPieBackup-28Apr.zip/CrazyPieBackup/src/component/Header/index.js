import React from 'react';
import { Row, Col, Progress } from 'antd';
import SerchBox from '../SearchBox';
import Notification from '../Notification';
import ProfileMenu from '../ProfileMenu';
import BurgerMenu from '../BurgerMenu';

const Header = (props) => {
    return (
        <>
            <Row className="container">
                <Progress percent={50} status="active" />
                <Col span={2}>
                    <BurgerMenu />
                </Col>
                <Col span={4}>
                    <h1 className="logo">
                        <b>CrazyPIE</b>
                    </h1>
                </Col>
                <Col span={12}>
                    <SerchBox />
                </Col>
                {
                    props.details !== null ?
                        (
                            <>
                                <Col span={3} >
                                    <Notification />
                                </Col>
                                <Col span={3}>
                                    <ProfileMenu />
                                </Col>
                            </>
                        ) : ""
                }
            </Row>
        </>
    );
};

export default Header;
