import React from 'react';
import Header from '../component/Header';

const App = () => {
    return (
        <Header iniVal ="hello" />
    );
};

export default App;

// const [count, setCount] = useState(0);
// return (
//     <div>
//         <h1>Hello CrazyPie App</h1>
//         <button onClick={() => setCount(count + 1)}>{count} - Hello-You will never go live</button>
//     </div>
// );
