import React, { useState } from 'react';
import { Row, Col } from 'antd';
import '../../style/customStyle.scss';
import { Input } from 'antd';
import { UserAddOutlined, UsergroupAddOutlined, MenuOutlined } from '@ant-design/icons';
const Header = (props) => {
    const [alert, showAlert] = useState('Hello');
    return (
        <>
            <Row className="container">
                <Col span={2}>
                    <MenuOutlined />
                </Col>
                <Col span={4}>
                    <h1 className="logo">
                        <b>CrazyPIE</b>
                    </h1>
                </Col>
                <Col span={12}>
                    <Row className="search-box">
                        <Input placeholder="Select Type of People You Want To Search" />
                        <Col className="individual" span={12}>
                            <a onClick={() => showAlert(console.log(alert))}>
                                <UserAddOutlined />
                            </a>
                        </Col>
                        <Col className="group" span={12}>
                            <a onClick={() => showAlert(console.log(alert))}>
                                <UsergroupAddOutlined />
                            </a>
                        </Col>
                    </Row>
                </Col>
                <Col span={6} />
            </Row>
        </>
    );
};

export default Header;
