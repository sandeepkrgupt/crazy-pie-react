const Event = require('../../models/event');
const Booking = require('../../models/booking');

const { transformBooking, transformEvent } = require('./merge');

module.exports = {
    bookings: async (args, req) => {
        if(!req.isAuth) {
            throw new Error('UnAuthenticated User!');
        }
        try {
            const bookingChahiye = await Booking.find();
            return bookingChahiye.map( habooking => {
                return transformBooking(habooking);
            })
        } catch(err) {

        }
    },
    bookEvent: async (args, req) => {
        if(!req.isAuth) {
            throw new Error('UnAuthenticated User!');
        }
        const fetchedEvent = await Event.findOne({ _id: args.eventId })
        const bookingCheckKar = new Booking({
            user: req.userId,
            event: fetchedEvent
        });
        const result = await bookingCheckKar.save();
        return transformBooking(result);
    },
    cancelBooking: async (args, req) => {
        if(!req.isAuth) {
            throw new Error('UnAuthenticated User!');
        }
        try {
            const grabBooking = await Booking.findById(args.bookingId).populate('event');
            const grabEvent = transformEvent(grabBooking.event);
            await Booking.deleteOne({ _id: args.bookingId });
            return grabEvent;
        } catch(err) {
            throw err;
        }
    }
}