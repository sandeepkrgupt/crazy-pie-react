const Event = require('../../models/event');
const User = require('../../models/user');
const { dateToString } = require('../../helpers/date');

const eventHai = async eventIds => {
    try {
        const okevt = await Event.find({ _id: { $in: eventIds } })
        return okevt.map(e => {
            return transformEvent(e);
        });
    } catch (err) {
        throw err;
    }
};
const eakhiEvent = async eventId => {
    try {
        const singleEvent = await Event.findById(eventId);
        return transformEvent(singleEvent);
    } catch(err) {
        throw err;
    }
}
const userHai = async userId => {
    try {
        const auser = await User.findById(userId)
        return {
            ...auser._doc,
            _id: auser.id,
            createdEvents: eventHai.bind(this, auser._doc.createdEvents)
        }
    } catch (err) {
        throw err;
    }
};

const transformEvent = eventArgs => {
    return {
        ...eventArgs._doc,
        _id: eventArgs.id,
        date: dateToString(eventArgs._doc.date),
        creator: userHai.bind(this, eventArgs.creator)
    };
};
const transformBooking = bookingArgs => {
    return {
        ...bookingArgs._doc,
        _id: bookingArgs.id,  
        user: userHai.bind(this, bookingArgs._doc.user),
        event: eakhiEvent.bind(this, bookingArgs._doc.event),
        createdAt: dateToString(bookingArgs._doc.createdAt),
        updatedAt: dateToString(bookingArgs._doc.updatedAt)
    };
};

exports.transformEvent = transformEvent;
exports.transformBooking = transformBooking;
//exports.userHai = userHai;
//exports.eventHai = eventHai;
//exports.eakhiEvent = eakhiEvent;