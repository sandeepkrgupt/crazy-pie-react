const User = require('../../models/user');
const Event = require('../../models/event');

const { transformEvent } = require('./merge');

module.exports = {
    events: async () => {
        try {
            const events = await Event.find()
            return events.map(evt => {
                return transformEvent(evt);
            });
        } catch (err) {
            throw err;
        }
    },
    createEvent: async (args, req) => {
        if(!req.isAuth) {
            throw new Error('UnAuthenticated User!');
        }
        const event = new Event({
            title: args.eventInput.title,
            description: args.eventInput.description,
            price: +args.eventInput.price,
            date: new Date(args.eventInput.date),
            creator: req.userId
        });
        let createdEvents;
        try {
            const result = await event.save()
            createdEvents = transformEvent(result);
            const usr = await User.findById(req.userId);
            if (!usr) {
                throw new Error('User Not Found');
            };
            usr.createdEvents.push(event);
            await usr.save();
            return createdEvents // don't need _id: result._doc._id.toString()
        } catch (err) {
            throw err;
        }
    }
}
