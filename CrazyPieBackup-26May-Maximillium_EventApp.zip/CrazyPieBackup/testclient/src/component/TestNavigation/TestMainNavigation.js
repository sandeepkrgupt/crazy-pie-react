import React from 'react';
import { NavLink } from 'react-router-dom';
import './MainNavigation.css';
import AuthContext from '../../TestContext/auth-context';

//debugger;
const MainNavigation = props => (
    <AuthContext.Consumer>
        {/* we did not pass any props to the child apps instead
        we wrapped our content in a Consumer */}
        {(context) => {
            return (
                <header className="main-navigation">
                    <div className="main-navigation__logo">
                        <h1>Easy Events</h1>
                    </div>
                    <nav className="main-navigation__item">
                        <ul>
                            {!context.token && <li>
                                <NavLink to="/auth">Authetication</NavLink>
                            </li>}
                            <li>
                                <NavLink to="/events">Events</NavLink>
                            </li>
                            {context.token && <li>
                                <NavLink to="/bookings">Bookings</NavLink>
                            </li>}
                        </ul>
                    </nav>
                </header>
            );
        }}
    </AuthContext.Consumer>
);
// this is single but look like multiline so no need return
export default MainNavigation;
