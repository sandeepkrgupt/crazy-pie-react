import React from 'react';
import ReactDOM from 'react-dom';
import ApolloClient from 'apollo-boost';// this add 1MB
import { ApolloProvider } from 'react-apollo';// this add 500KB
import TestApp from './component/TestApp';

var URL = "http://localhost:4000/graphql";
var client = new ApolloClient({
    uri: URL
});
ReactDOM.render(
    <ApolloProvider client={client}>
        <TestApp />
    </ApolloProvider>,
    document.getElementById('root')
);
