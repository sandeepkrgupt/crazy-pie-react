import React, { Component } from 'react';

class BookingsPage extends Component {
    render () {
        return (
            <h1>The BookingsPage</h1>
        );
    }
}
export default BookingsPage;


