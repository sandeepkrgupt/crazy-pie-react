import React, { useRef, useState, useContext } from 'react';
import AuthContext from '../TestContext/auth-context';

const UserAuthPage = (props) => {
    const [state, toggleState] = useState({ isLogin: true });
    const consumerValue = useContext(AuthContext);
    /** Toggle b/w login and signup */
    const switchModeHandler = () => {
        toggleState(prevState => {
            return { isLogin: !prevState.isLogin };
        });
    };
    const emailEl = useRef(null);
    const passwordEl = useRef(null);
    const submitHandler = (event) => {
        event.preventDefault();
        const email = emailEl.current.value;
        const password = passwordEl.current.value;
        if (email.trim().length === 0 || password.trim().length === 0) {
            return;
        }
        let requestBody = {
            query:
                `query {
                login(email: "${email}", password:"${password}") {
                    userId
                    token
                    tokenExpiration
                }
            }`
        };
        console.log('-', state.isLogin);
        if (!state.isLogin) {
            requestBody = {
                query:
                    `mutation {
                        createUser(userInput: {email: "${email}", password:"${password}"}) {
                            _id
                            email
                        }
                   }`
            };
        }
        fetch('http://localhost:3000/graphql', {
            method: 'POST',
            body: JSON.stringify(requestBody),
            headers: {
                'Content-Type': 'application/json'
            }
        })
            .then(res => {
                if (res.status !== 200 && res.status !== 201) {
                    throw new Error('Failed!');
                }
                return res.json();
            })
            .then(resData => {
                if (resData.data.login.token) {
                    consumerValue.login(
                        resData.data.login.token,
                        resData.data.login.userId,
                        resData.data.login.tokenExpiration
                    );
                }
            })
            .catch(err => {
                console.log('err', err);
            });
    };

    return (
        <form onSubmit={submitHandler}>
            <div className="form-control">
                <label htmlFor="email"> Email</label>
                <input type="email" id="email" ref={emailEl} />
            </div>
            <div className="form-control">
                <label htmlFor="password"> Password</label>
                <input type="password" id="passord" ref={passwordEl} />
            </div>
            <div className="form-action">
                <button type="button" onClick={switchModeHandler}>
                    Swith to {state.isLogin ? 'Signup' : 'Login'}
                </button>
                <button type="submit">Submit</button>
            </div>
        </form>
    );
};

export default UserAuthPage;
