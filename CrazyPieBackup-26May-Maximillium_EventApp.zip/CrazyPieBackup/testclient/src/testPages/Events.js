import React, { Component } from 'react';

class EventsPage extends Component {
    render () {
        return (
            <h1>The Events Page</h1>
        );
    }
}
export default EventsPage;
