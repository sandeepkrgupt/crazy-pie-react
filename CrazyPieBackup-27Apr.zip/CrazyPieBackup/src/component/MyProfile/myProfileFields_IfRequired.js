<Form.Item
		name="name"
		label="Name"
		rules={[
			{
				required: true,
				message: 'Please input your name!',
				whitespace: true
			}
		]}
	>
		<Input placeholder="Sandeep Kumar" />
	</Form.Item>
	<Form.Item
		name="password"
		label="Password"
		rules={[
			{
				required: true,
				message: 'Please input your password!'
			}
		]}
	//hasFeedback
	>
		<Input.Password placeholder="*******" />
	</Form.Item>
	<Form.Item
		name="passion"
		label="Passion"
		rules={[
			{
				required: true,
				message: 'Please input your passion!',
				whitespace: true
			}
		]}
	>
		<Input placeholder="Singing" />
	</Form.Item>
	<Form.Item
		name="profession"
		label="Profession"
		rules={[
			{
				required: true,
				message: 'Please input your profession!',
				whitespace: true
			}
		]}
	>
		<Input placeholder="Engineer" />
	</Form.Item>
	<Form.Item
		name="area"
		label="Area"
		rules={[
			{
				required: true,
				message: 'Please input your area name!'
			}
		]}
	>
		<Input placeholder="Kharadi" />
	</Form.Item>
	<Form.Item
		name="city"
		label="City"
		rules={[
			{
				required: true,
				message: 'Please input your city!'
			}
		]}
	>
		<Input placeholder="Pune" />
	</Form.Item>
	<Form.Item
		name="state"
		label="State"
		rules={[
			{
				required: true,
				message: 'Please input your state!'
			}
		]}
	>
		<Input placeholder="Maharastra" />
	</Form.Item>
	<Form.Item
		name="country"
		label="Country"
		rules={[
			{
				required: true,
				message: 'Please input your country!'
			}
		]}
	>
		<Input placeholder="india" />
	</Form.Item>