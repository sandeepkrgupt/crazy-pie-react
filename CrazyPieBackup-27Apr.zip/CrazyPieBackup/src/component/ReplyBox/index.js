import React from 'react';
import { Input } from 'antd';
import { SendOutlined } from '@ant-design/icons';

const ReplayBox = () => {
    return (
        <div className="user-profile-reply-box">
            <Input placeholder="Send Message" />
            <SendOutlined onClick={() => console.log('Sent')} />
        </div>
    );
};

export default ReplayBox;
