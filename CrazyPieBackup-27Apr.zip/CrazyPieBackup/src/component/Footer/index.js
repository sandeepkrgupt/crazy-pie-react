import React from 'react';
import { Row, Col } from 'antd';

const Footer = () => {
    return (
        <Row>
            <Col span={24}> Footer</Col>
        </Row>
    );
};

export default Footer;
