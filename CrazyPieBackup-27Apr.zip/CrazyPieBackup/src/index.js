import React from 'react';
import ReactDOM from 'react-dom';
import App from './component/App.js';
import 'antd/dist/antd.css';
import '../style/customStyle.scss';
ReactDOM.render(<App />, document.getElementById('root'));
