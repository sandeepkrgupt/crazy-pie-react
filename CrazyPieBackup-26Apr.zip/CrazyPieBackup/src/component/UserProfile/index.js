import React from 'react';
import { Row, Col, Form, PageHeader, Button, Card } from 'antd';

const UserProfile = () => {
    const [form] = Form.useForm();
    const onFinish = values => {
        console.log('Values are --: ', values);
    };
    return (
        <>
            <Row className="my-profile">
                <Col span={2} />
                <Col span={20}>
                    <PageHeader title="User Profile" />
                    <Row>
                        <Col span={8}>
                            <Card
                                cover={<img alt="example" src="https://os.alipayobjects.com/rmsportal/QBnOOoLaAfKPirc.png" />}
                                style={{ marginRight: '1rem' }}
                            />
                        </Col>
                        <Col span={16}>
                            <PageHeader title="Details" />
                            <p>rem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        </Col>
                    </Row>
                </Col>
                <Col span={2} />
            </Row>
            <Row>
                <Col span={2} />
                <Col span={20}>
                    <div className="user-profile-experience">
                        <PageHeader title="Experience" />
                        <p>rem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                    </div>
                    <div className="user-profile-achievements">
                        <PageHeader title="Achievements" />
                        <p>rem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                    </div>
                    <div>
                        <Form
                            form={form}
                            name="register"
                            onFinish={onFinish}
                            //initialValues={{ email: 'abc.com' }}
                            scrollToFirstError
                        >
                            User Profile
                            <Form.Item>
                                <Button type="primary" htmlType="submit">
                                    Add
                                </Button>
                            </Form.Item>
                        </Form>
                    </div>
                </Col>
                <Col span={2} />
            </Row>
        </>
    );
};

export default UserProfile;
