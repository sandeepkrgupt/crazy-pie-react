import React from 'react';
import { Form, Input, Tooltip, Row, Col, Checkbox, Button, DatePicker, PageHeader } from 'antd';
import { QuestionCircleOutlined } from '@ant-design/icons';
//import allSignUpFields from '../../../public/signUpFields';

var Promise = require('es6-promise').Promise; // npm i es6-promise
const UserSignUp = () => {
    let userId = '';
    const [form] = Form.useForm();
    const onFinish = values => {
        const nameForUserId = values.name.replace(/\s/g, '');
        const phoneForUserId = values.phone.slice(6);
        userId = nameForUserId.toLowerCase() + '_' + phoneForUserId;
        console.log('your username is: ', userId);
    };
    //const allFields = allSignUpFields.map((p) => <Form.Item name={p.name} label={p.label} rules={p.rules}><Input /><DatePicker /></Form.Item>)
    return (
        <Form
            form={form}
            name="register"
            onFinish={onFinish}
            //initialValues={{ email: 'abc.com' }}
            scrollToFirstError
        >
            <PageHeader title="Sign Up" />
            <Row>
                <Col span={24}>
                    <Form.Item
                        name="name"
                        label="Name"
                        rules={[
                            {
                                required: true,
                                message: 'Please input your name!',
                                whitespace: true
                            }
                        ]}
                    >
                        <Input />
                    </Form.Item>
                    <Form.Item
                        name="passion"
                        label="Passion"
                        rules={[
                            {
                                required: true,
                                message: 'Please input your passion!',
                                whitespace: true
                            }
                        ]}
                    >
                        <Input />
                    </Form.Item>
                    <Form.Item
                        name="profession"
                        label="Profession"
                        rules={[
                            {
                                required: true,
                                message: 'Please input your profession!',
                                whitespace: true
                            }
                        ]}
                    >
                        <Input />
                    </Form.Item>
                    <Form.Item
                        name="email"
                        label={
                            <span>
                                E-Mail&nbsp;
                                <Tooltip title="Don't worry, Your Email is safe with us.">
                                    <QuestionCircleOutlined />
                                </Tooltip>
                            </span>
                        }
                        rules={[
                            {
                                type: 'email',
                                message: 'The input is not valid E-mail!'
                            },
                            {
                                required: true,
                                message: 'Please input your E-mail!'
                            }
                        ]}
                    >
                        <Input placeholder="Please Enter Your Gmail/Yahoo/Outlook" />
                    </Form.Item>
                    <Form.Item
                        name="password"
                        label="Password"
                        rules={[
                            {
                                required: true,
                                message: 'Please input your password!'
                            }
                        ]}
                    //hasFeedback
                    >
                        <Input.Password />
                    </Form.Item>
                    <Form.Item
                        name="confirm"
                        label="Confirm Password"
                        dependencies={['password']}
                        //hasFeedback
                        rules={[
                            {
                                required: true,
                                message: 'Please confirm your password!'
                            },
                            ({ getFieldValue }) => ({
                                validator (rule, value) {
                                    if (!value || getFieldValue('password') === value) {
                                        return Promise.resolve();
                                    }

                                    return Promise.reject('The two passwords that you entered do not match!');
                                }
                            })
                        ]}
                    >
                        <Input.Password />
                    </Form.Item>
                    <Form.Item
                        name="phone"
                        label="Phone Number"
                        rules={[
                            {
                                required: true,
                                message: 'Please input your phone number!'
                            }
                        ]}
                    >
                        <Input
                            style={{
                                width: '100%'
                            }}
                        />
                    </Form.Item>
                    <Form.Item
                        name="dateofbirth"
                        label="Date Of Birth"
                        rules={[
                            {
                                required: true,
                                message: 'Please select your date of birth!'
                            }
                        ]}
                    >
                        <DatePicker
                            style={{
                                width: '100%'
                            }}
                        />
                    </Form.Item>
                </Col>
            </Row>
            <Form.Item label="Captcha" extra="We must make sure that your are a human.">
                <Row gutter={8}>
                    <Col span={12}>
                        <Form.Item
                            name="captcha"
                            noStyle
                            rules={[
                                {
                                    required: true,
                                    message: 'Please input the captcha you got!'
                                }
                            ]}
                        >
                            <Input />
                        </Form.Item>
                    </Col>
                    <Col span={12}>
                        <Button>Get captcha</Button>
                    </Col>
                </Row>
            </Form.Item>
            <Form.Item
                name="agreement"
                valuePropName="checked"
                rules={[
                    {
                        validator: (_, value) =>
                            value ? Promise.resolve() : Promise.reject('Should accept agreement')
                    }
                ]}
            >
                <Checkbox>
                    I have read the <a href="">agreement</a>
                </Checkbox>
            </Form.Item>
            <Form.Item>
                <Button type="primary" htmlType="submit">
                    Register
                </Button>
            </Form.Item>
        </Form>
    );
};

export default UserSignUp;
