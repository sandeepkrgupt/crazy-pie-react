import React from 'react';
import { Carousel } from 'antd';

function onChange (a, b, c) {
    console.log('->>>>', a, b, c);
}

const UserCarousel = () => {
    return (
        <Carousel afterChange={onChange}>
            <div>
                <img src="https://www.dawsons.co.uk/blog/wp-content/uploads/2015/06/Playing-Guitar.jpg" />
            </div>
            <div>
                <h3>2dfdsfdsfsdf</h3>
            </div>
            <div>
                <h3>3dfdsfd</h3>
            </div>
            <div>
                <h3>4sdsdsds</h3>
            </div>
        </Carousel>
    );
};

export default UserCarousel;
