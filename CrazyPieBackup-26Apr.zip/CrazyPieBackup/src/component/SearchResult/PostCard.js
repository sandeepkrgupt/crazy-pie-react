import React, { useState } from 'react';
import { Card, Avatar, Button } from 'antd';
import { LikeFilled } from '@ant-design/icons';
import UserCarousel from '../Carousel';

const { Meta } = Card;
const UserPostCard = (props) => {
    const [cardMsg = 'hello', setCardMsg] = useState();
    return (
        <>
            <Card
                cover={
                    <UserCarousel />
                }
                actions={[
                    <LikeFilled style={{ fontSize: '2.5em', textAlign: 'left' }} />,
                    <p className="post-like-count">100</p>,
                ]}
            >
                <Meta
                    avatar={<Avatar src="https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png" />}
                    title="Tom Jolly : Guitarist"
                    description="Passion"
                />
                <Button onClick={() => setCardMsg(console.log(cardMsg))} style={{ float: 'right' }}>Open Profile</Button>
            </Card>
        </>
    );
};

export default UserPostCard;

