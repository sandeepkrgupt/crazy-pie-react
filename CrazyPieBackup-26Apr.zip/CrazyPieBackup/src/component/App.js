import React from 'react';
import Header from '../component/Header';
import UserSuggestionBox from './UserSuggestionBox';
//import ActivityBox from './ActivityBox';
import Footer from './Footer';
import UserPosts from './SearchResult';
import { Row, Col } from 'antd';
//import MyProfile from './MyProfile';
//import UserLogIn from './Login'./MyProfile/multipleImageUploadGrid
//import UserSignUp from './SignUp';
//import UserProfile from './UserProfile';
import mockData from '../../public/mockData.json';
const App = () => {
    const userData = mockData;
    return (
        <>
            <Header details={userData} />
            <section>
                <Row>
                    <Col span={2} />
                    <Col span={20}>
                        {
                            userData ?
                                (
                                    <div className="site-content-area">
                                        {/* <ActivityBox /> */}
                                        <UserSuggestionBox details={userData} />
                                        <hr/>
                                        <UserPosts details={userData} />
                                    </div>
                                ) :
                                (
                                    <div className="user-signup-form">
                                        <UserProfile />
                                    </div>
                                )
                        }
                        <Footer />
                    </Col>
                    <Col span={2} />
                </Row>
            </section>
        </>
    );
};

export default App;


