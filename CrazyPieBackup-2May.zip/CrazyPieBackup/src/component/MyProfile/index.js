import React from 'react';
import { Row, Col, Form, Input, PageHeader, Button, message } from 'antd';
import ProfileImage from './profileImage';
import MultipleImageUpload from '../MultipleImageUpload';
import myProfileFields from '../../../public/myProfileFields.json';
const fieldsData = myProfileFields;
const MyProfile = () => {
    const [form] = Form.useForm();
    const onFinish = values => {
        console.log('your username is --: ', values);
    };
    const onFinishFailed = errorInfo => {
        errorInfo.errorFields.find((p) => message.error(p.errors[0]));
        console.log('Failed:', errorInfo);
    };
    const arrMap = fieldsData.map((p) => {
        return (
            <Form.Item
                name={p.name}
                label={p.label}
                rules={p.rules}
            ><Input placeholder={p.placeholder} />
            </Form.Item>);
    });
    return (
        <>
            <Row className="my-profile">
                <Col span={2} />
                <Col span={20}>
                    <PageHeader title="Profile" />
                    <Row>
                        <Col span={6}>
                            <ProfileImage />
                        </Col>
                        <Col span={12}>
                            <Form
                                form={form}
                                name="register"
                                onFinish={onFinish}
                                onFinishFailed={onFinishFailed}
                                //initialValues={{ email: 'abc.com' }}
                                scrollToFirstError
                            >
                                {arrMap}
                                <Form.Item>
                                    <Button type="primary" htmlType="submit">
                                        Update Profile
                                    </Button>
                                </Form.Item>
                            </Form>
                        </Col>
                    </Row>
                    <MultipleImageUpload />
                </Col>
                <Col span={2} />
            </Row>
        </>
    );
};

export default MyProfile;
