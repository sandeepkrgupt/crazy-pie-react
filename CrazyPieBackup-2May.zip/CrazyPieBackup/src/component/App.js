import React from 'react';
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import SignUp from './SignUp';
import LogIn from './Login';
import HomePage from './HomePage';
import CreateEvent from './CreateEvent';
import CreateGroup from './CreateGroup';
//import Header from '../component/Header';
//import ActivityBox from './ActivityBox';
//import { Row, Col } from 'antd';
//import Navigation from "./Navigation";
// import ActivityBox from './ActivityBox';
// import UserSuggestionBox from './UserSuggestionBox';
// import MyProfile from './MyProfile';
// import UserProfile from './UserProfile';
// import Chat from './Chat';
//import Footer from './Footer';
//import mockData from '../../public/mockData.json';
//import SimpleSlider from './Carousel/test';
const App = () => (
    <Router>
        <div className="container">
            <Switch>
                <Route path="/signup">
                    <SignUp />
                </Route>
                <Route path="/login">
                    <LogIn />
                </Route>
                <Route path="/create-event">
                    <CreateEvent />
                </Route>
                <Route path="/create-group">
                    <CreateGroup />
                </Route>
                <Route path="/">
                    <HomePage />
                </Route>
            </Switch>
        </div>
    </Router>
);

export default App;


