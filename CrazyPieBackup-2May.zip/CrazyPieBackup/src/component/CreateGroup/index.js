import React from 'react';
import { Row, Col, PageHeader, Form, Input, Button, Tooltip, message } from 'antd';
import { QuestionCircleOutlined } from '@ant-design/icons';
import TextArea from 'antd/lib/input/TextArea';
import moment from 'moment';
import AddFriendAutocompleteTextBox from '../AddFriendTextBox';
import MultipleImageUpload from '../MultipleImageUpload';
import AutoCompleteSelectResult from '../AutoCompleteSelectBox';
import BackButton from '../BackButton';

const CreateGroup = () => {
    const [form] = Form.useForm();
    const onFinish = values => {
        const groupCreationDate = moment.now();
        console.log('Group id is =', values.groupname + '_' + groupCreationDate);
    };
    const onFinishFailed = errorInfo => {
        errorInfo.errorFields.find((p) => message.error(p.errors[0]));
        console.log('Failed:', errorInfo);
    };
    return (
        <>
            <BackButton />
            <Row className="create-group">
                <Col span={2} />
                <Col span={20}>
                    <Form
                        form={form}
                        name="register"
                        onFinish={onFinish}
                        onFinishFailed={onFinishFailed}
                        //initialValues={{ email: 'abc.com' }}
                        scrollToFirstError
                    >
                        <PageHeader title="Create A Group" />
                        <Row>
                            <Col span={24}>
                                <Form.Item
                                    name="groupname"
                                    label="Group Name"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your group name!',
                                            whitespace: true
                                        }
                                    ]}
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    name="group_type"
                                    label="Group Type"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your group type!',
                                            whitespace: true
                                        }
                                    ]}
                                >
                                    <AutoCompleteSelectResult />
                                </Form.Item>
                                <Form.Item
                                    name="slogan"
                                    label="Slogan"
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    name="details"
                                    label="Details"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input group details!',
                                            whitespace: true
                                        }
                                    ]}
                                >
                                    <TextArea rows={4} />
                                </Form.Item>
                                <Form.Item
                                    name="addmembers"
                                    label={
                                        <span>
                                            Add Members&nbsp;
                                            <Tooltip title="Use member_id to search">
                                                <QuestionCircleOutlined />
                                            </Tooltip>
                                        </span>
                                    }
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please add your group members!',
                                            whitespace: true
                                        }
                                    ]}
                                >
                                    <AddFriendAutocompleteTextBox />
                                </Form.Item>
                                <Form.Item>
                                    <MultipleImageUpload />
                                </Form.Item>
                                <Form.Item>
                                    <Button type="primary" htmlType="submit">
                                        Create Group
                                    </Button>
                                </Form.Item>
                            </Col>
                        </Row>
                    </Form>
                </Col>
                <Col span={2} />
            </Row>
        </>
    );
};

export default CreateGroup;
