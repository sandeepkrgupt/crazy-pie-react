import React from 'react';
import { Card } from 'antd';
//import Slider from "react-slick";

const { Meta } = Card;
const UserSuggestionCard = (props) => {
    const {
        alt,
        src,
        title,
        description
    } = props;

    return (
        <Card className="user-suggestion-cards"
            hoverable
            style={{ width: '12vw', margin: '2%' }}
            cover={<img alt={alt} src={src} />}
        >
            <Meta title={title} description={description} />
        </Card>
    );
};

export default UserSuggestionCard;
