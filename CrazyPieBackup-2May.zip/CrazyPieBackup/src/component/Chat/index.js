import React, { useState } from 'react';
import { Row, Col, Comment, Avatar, Form, List, Button, Input, PageHeader } from 'antd';
import moment from 'moment';

const { TextArea } = Input;

const CommentList = ({ comments }) => (
    <List
        dataSource={comments}
        itemLayout="horizontal"
        renderItem={props => <Comment {...props} />}
    />
);

const Editor = ({ onChange, onSubmit, submitting, value }) => (
    <div>
        <Form.Item>
            <TextArea rows={1} onChange={onChange} value={value} />
        </Form.Item>
        <Form.Item>
            <Button htmlType="submit" loading={submitting} onClick={onSubmit} type="primary">
                Add Comment
            </Button>
        </Form.Item>
    </div>
);

const Chat = () => {
    let [state = {
        comments: [],
        submitting: false,
        value: ''
    },
    setState] = useState();

    const handleChange = event => {
        setState({
            value: event.target.value,
        });
    };
    const handleSubmit = () => {
        if (!state.value) {
            return;
        }

        setState({
            submitting: true,
        });

        setTimeout(() => {
            setState({
                submitting: false,
                value: '',
                comments: [
                    {
                        author: 'Han Solo',
                        avatar: 'https://zos.alipayobjects.com/rmsportal/ODTLcjxAfvqbxHnVXCYX.png',
                        content: <p>{state.value}</p>,
                        datetime: moment().fromNow(),
                    },
                    //...state.comments,
                ],
            });
        }, 1000);
    };
    const { comments, submitting, value } = state;
    return (
        <Row>
            <PageHeader title="Chat" />
            <Col span={2} />
            <Col span={14}>
                <div>
                    {comments && <CommentList comments={comments} />}
                    <Comment
                        avatar={
                            <Avatar
                                src="https://cdn.mos.cms.futurecdn.net/3z2jp4Hurn4Ak4TAXWgyj6-1200-80.jpg"
                                alt="Han Soloeee"
                            />
                        }
                        content={
                            <Editor
                                onChange={(e) => handleChange(e)}
                                onSubmit={handleSubmit}
                                submitting={submitting}
                                value={value}
                            />
                        }
                    />
                </div>
            </Col>
            <Col span={8} />
        </Row>
    );
};

export default Chat;
