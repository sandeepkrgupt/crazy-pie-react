import React from 'react';
import Header from '../Header';
import Footer from '../Footer';
import { Row, Col } from 'antd';
import UserSuggestionBox from '../UserSuggestionBox';
import UserPosts from '../SearchResult';
import mockData from '../../../public/mockData.json';
const HomePage = () => {
    const userData = mockData;
    return (
        <>
            <Header details={userData} />
            <section>
                <Row>
                    <Col span={2} />
                    <Col span={20}>
                        <div className="site-content-area">
                            <div>
                                <UserSuggestionBox details={userData} />
                                <hr/>
                                <UserPosts />
                            </div>
                        </div>
                        <Footer />
                    </Col>
                    <Col span={2} />
                </Row>
            </section>
        </>
    );
};

export default HomePage;
