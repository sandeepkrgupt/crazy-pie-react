import React from 'react';
import { Row, Col, PageHeader, Form, Input, Button, message } from 'antd';
import TextArea from 'antd/lib/input/TextArea';
import moment from 'moment';
import AutoCompleteSelectResult from '../AutoCompleteSelectBox';
import MultipleImageUpload from '../MultipleImageUpload';
import BackButton from '../BackButton';

const CreateEvent = () => {
    const [form] = Form.useForm();
    const onFinish = values => {
        const groupCreationDate = moment.now();
        console.log('Group id is =', values.groupname + '_' + groupCreationDate);
    };
    const onFinishFailed = errorInfo => {
        errorInfo.errorFields.find((p) => message.error(p.errors[0]));
        console.log('Failed:', errorInfo);
    };
    return (
        <>
            <BackButton />
            <Row className="create-group">
                <Col span={2} />
                <Col span={20}>
                    <Form
                        form={form}
                        name="register"
                        onFinish={onFinish}
                        onFinishFailed={onFinishFailed}
                        //initialValues={{ email: 'abc.com' }}
                        scrollToFirstError
                    >
                        <PageHeader title="Create An Event" />
                        <Row>
                            <Col span={24}>
                                <Form.Item
                                    name="eventname"
                                    label="Event Name"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your event name!',
                                            whitespace: true
                                        }
                                    ]}
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    name="eventtype"
                                    label="Event Type"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input your event type!',
                                            whitespace: true
                                        }
                                    ]}
                                >
                                    <AutoCompleteSelectResult />
                                </Form.Item>
                                <Form.Item
                                    name="slogan"
                                    label="Slogan"
                                >
                                    <Input />
                                </Form.Item>
                                <Form.Item
                                    name="details"
                                    label="Details"
                                    rules={[
                                        {
                                            required: true,
                                            message: 'Please input event details!',
                                            whitespace: true
                                        }
                                    ]}
                                >
                                    <TextArea rows={4} />
                                </Form.Item>
                                <Form.Item>
                                    <MultipleImageUpload />
                                </Form.Item>
                                <Form.Item>
                                    <Button type="primary" htmlType="submit">
                                        Create Event
                                    </Button>
                                </Form.Item>
                            </Col>
                        </Row>
                    </Form>
                </Col>
                <Col span={2} />
            </Row>
        </>
    );
};

export default CreateEvent;
