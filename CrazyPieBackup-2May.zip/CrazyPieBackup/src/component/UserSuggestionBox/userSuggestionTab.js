import React from 'react';
import { Tabs, Row, Col, Button } from 'antd';
import UserSuggestionCard from '../UserSuggestionCard';
const { TabPane } = Tabs;

const UserSuggestionTab = (props) => {
    const allUsers = props.details.map((p) => <UserSuggestionCard key={props.details.id} {...p} />);
    const state = {
        mode: 'left'
    };
    const { mode } = state;
    return (
        <div className="user-suggestion-tab">
            <Tabs defaultActiveKey="1" tabPosition={mode} style={{ width: '100%', height: '100%' }}>
                <TabPane tab={`Friends`} key={1}>
                    <Row>
                        <Col span={24}>
                            {allUsers}
                        </Col>
                    </Row>
                    <Row>
                        <Col span={24}>
                            <Button type="primary" className="btn-prev-card">Previous Suggestion</Button>&nbsp;
                            <Button type="primary" className="btn-next-card">Next Suggestion</Button>
                        </Col>
                    </Row>
                </TabPane>
                <TabPane tab={`Groups`} key={2}>
                    <Row>
                        <Col span={24}>
                            <Button type="primary" className="btn-prev-card">Previous Suggestion</Button>&nbsp;
                            <Button type="primary" className="btn-next-card">Next Suggestion</Button>
                        </Col>
                    </Row>
                </TabPane>
            </Tabs>
        </div>
    );
};

export default UserSuggestionTab;
