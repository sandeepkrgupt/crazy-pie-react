import React from 'react';
//import UserSuggestionCard from '../UserSuggestionCard';
import { Row } from 'antd';
import UserSuggestionTab from './userSuggestionTab';

const UserSuggestionBox = (props) => {
    //const allUsers = props.details.map((p) => <UserSuggestionCard key={props.details.id} {...p} />);
    return (
        <>
            <Row className="user-suggestion-box">
                <UserSuggestionTab {...props} />
            </Row>
        </>
    );
};

export default UserSuggestionBox;
