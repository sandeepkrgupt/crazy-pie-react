import React from 'react';
import { useHistory } from "react-router-dom";
import { Button } from 'antd';
import { LeftOutlined } from '@ant-design/icons';

const BackButton = () => {
    const state = {
        size: 'large',
    };
    let history = useHistory();
    const goToPreviousPath = () => {
        history.goBack();
    };
    const { size } = state;
    return (
        <div>
            <Button
                type="primary"
                icon={<LeftOutlined />}
                size={size}
                onClick={goToPreviousPath}
            >
                Back
            </Button>
        </div>
    );
};

export default BackButton;


