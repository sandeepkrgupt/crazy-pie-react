import React from 'react';
import { Drawer } from 'antd';
import { Link } from "react-router-dom";
import { Menu } from 'antd';
import { UserAddOutlined, UserSwitchOutlined, CalendarOutlined, UsergroupAddOutlined } from '@ant-design/icons';

const LeftDrawer = (props) => {
    return (
        <div>
            <Drawer
                title={props.title}
                placement="left"
                closable={false}
                onClose={() => props.showDrawer(false)}
                visible={props.visible}
                width={340}
            >
                <Menu>
                    <Menu.Item
                        key="1"
                    >
                        <Link to="/signup">
                            <span>
                                <UserAddOutlined />
                            </span>
                            Sign Up
                        </Link>
                    </Menu.Item>
                    <Menu.Item
                        key="2"
                    >
                        <Link to="/login">
                            <span>
                                <UserSwitchOutlined />
                            </span>
                            Login
                        </Link>
                    </Menu.Item>
                    <Menu.Item
                        key="3"
                    >
                        <Link to="/create-event">
                            <span>
                                <CalendarOutlined />
                            </span>
                            Create Event
                        </Link>
                    </Menu.Item>
                    <Menu.Item
                        key="4"
                    >
                        <Link to="/create-group">
                            <span>
                                <UsergroupAddOutlined />
                            </span>
                            Create Group
                        </Link>
                    </Menu.Item>
                </Menu>
            </Drawer>
        </div>
    );
};

export default LeftDrawer;


