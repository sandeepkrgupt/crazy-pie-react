import React from 'react';
import ReactDOM from 'react-dom';
import App from './component/App.js';
import 'antd/dist/antd.css';

ReactDOM.render(<App />, document.getElementById('root'));
