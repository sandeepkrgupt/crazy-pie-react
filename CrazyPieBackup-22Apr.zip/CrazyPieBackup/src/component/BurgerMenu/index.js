import React, { useState } from 'react';
import { Row, Col } from 'antd';
import { MenuOutlined } from '@ant-design/icons';
import LeftDrawer from '../LeftDrawer';

const BurgerMenu = () => {
    const [visible = false, showDrawer, title = 'Menu'] = useState();
    return (
        <>
            <Row className="burger-menu-tab">
                <Col>
                    <MenuOutlined onClick={() => showDrawer(true)} />
                </Col>
            </Row>
            <LeftDrawer title={title} visible={visible} showDrawer={showDrawer} />
        </>
    );
};

export default BurgerMenu;
