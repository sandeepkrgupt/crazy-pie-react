import React from 'react';
import { Carousel } from 'antd';

function onChange (a, b, c) {
    console.log('->>>>', a, b, c);
}

const UserCarousel = () => {
    return (
        <Carousel afterChange={onChange}>
            <div>
                <h3>1dsfdsfdsfdsf</h3>
            </div>
            <div>
                <h3>2dfdsfdsfsdf</h3>
            </div>
            <div>
                <h3>3dfdsfd</h3>
            </div>
            <div>
                <h3>4sdsdsds</h3>
            </div>
        </Carousel>
    );
};

export default UserCarousel;
