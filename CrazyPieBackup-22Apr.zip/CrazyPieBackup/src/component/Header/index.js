import React from 'react';
import { Row, Col } from 'antd';
import '../../style/customStyle.scss';
import SerchBox from '../SearchBox/index';
import Notification from '../Notification/index';
import UserProfileMenu from '../UserProfileMenu/index';
import BurgerMenu from '../BurgerMenu';

const Header = (props) => {
    return (
        <>
            <Row className="container">
                <Col span={2}>
                    <BurgerMenu />
                </Col>
                <Col span={4}>
                    <h1 className="logo">
                        <b>CrazyPIE</b>
                    </h1>
                </Col>
                <Col span={12}>
                    <SerchBox />
                </Col>
                <Col span={2} >
                    <Notification />
                </Col>
                <Col span={2}>
                    <UserProfileMenu />
                </Col>
            </Row>
        </>
    );
};

export default Header;
