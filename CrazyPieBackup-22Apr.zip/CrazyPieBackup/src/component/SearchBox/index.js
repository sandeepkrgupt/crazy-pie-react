import React, { useState } from 'react';
import { Row, Col } from 'antd';
import { Input } from 'antd';
import { UserAddOutlined, UsergroupAddOutlined, AimOutlined } from '@ant-design/icons';
const SearchBox = (props) => {
    const [alert, showAlert] = useState('Individual');
    return (
        <>
            <Row className="search-box">
                <Col span={18}>
                    <Input placeholder="Select Type of People You Want To Search" className="search-people" />
                    <Col className="individual-box" span={12}>
                        <a onClick={() => showAlert(console.log(alert))}>
                            <UserAddOutlined />
                        </a>
                    </Col>
                    <Col className="group-box" span={12}>
                        <a onClick={() => showAlert(console.log(alert))}>
                            <UsergroupAddOutlined />
                        </a>
                    </Col>
                </Col>

                <Col span={6}>
                    <Input placeholder="Enter City/Area" className="search-location" />
                    <Col className="access-location-box" span={24}>
                        <a onClick={() => showAlert(console.log(alert))}>
                            <AimOutlined />
                        </a>
                    </Col>
                </Col>
            </Row>
        </>
    );
};

export default SearchBox;
