import React, { useState } from 'react';
import { Row, Col } from 'antd';
import { UserOutlined } from '@ant-design/icons';
import RightDrawer from '../RightDrawer';

const UserProfileMenu = () => {
    const [visible = false, showDrawer, title = 'Profile'] = useState();
    return (
        <>
            <Row className="user-menu-tab">
                <Col>
                    <UserOutlined onClick={() => showDrawer(true)} />
                </Col>
            </Row>
            <RightDrawer title={title} visible={visible} showDrawer={showDrawer} />
        </>
    );
};

export default UserProfileMenu;
