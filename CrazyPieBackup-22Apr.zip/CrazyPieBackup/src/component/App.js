import React from 'react';
import Header from '../component/Header';
import UserSuggestionBox from './UserSuggestionBox';
import ActivityBox from './ActivityBox';
import Footer from './Footer';
import UserPosts from './UserPosts';

const App = () => {
    const userData = [{
        alt: 'TOM Jesler',
        src: 'https://os.alipayobjects.com/rmsportal/QBnOOoLaAfKPirc.png',
        title: 'Tom Jesler',
        description: 'Guitarist | England'
    }, {
        alt: 'TOM Jesler',
        src: 'https://www.expressandstar.com/resizer/PtkZFg8g4ItXUGAnFo46lNjUKOI=/1000x0/filters:quality(100)/arc-anglerfish-arc2-prod-expressandstar-mna.s3.amazonaws.com/public/B5LT7G2NEFCOBIU33P546MZGKM.jpg',
        title: 'Tom Jesler',
        description: 'Guitarist | England'
    }, {
        alt: 'TOM Jesler',
        src: 'https://www.guitarplayer.com/.image/t_share/MTUxNDE4Mjk4NjU5ODQxMjc5/image-placeholder-title.jpg',
        title: 'Tom Jesler',
        description: 'Guitarist | England'
    }, {
        alt: 'TOM Jesler',
        src: 'https://www.dawsons.co.uk/blog/wp-content/uploads/2015/06/Playing-Guitar.jpg',
        title: 'Tom Jesler',
        description: 'Guitarist | England'
    }, {
        alt: 'TOM Jesler',
        src: 'https://cdn.mos.cms.futurecdn.net/3z2jp4Hurn4Ak4TAXWgyj6-1200-80.jpg',
        title: 'Tom Jesler',
        description: 'Guitarist | England'
    }, {
        alt: 'TOM Jesler',
        src: 'https://i.ytimg.com/vi/Crw9X_hW-bE/maxresdefault.jpg',
        title: 'Tom Jesler',
        description: 'Guitarist | England'
    }];
    const userdtls = userData;
    return (
        <>
            <Header iniVal="hello" />
            <div className="user-suggestion-box">
                <UserSuggestionBox details={userdtls} />
            </div>
            <hr />
            <div>
                <ActivityBox />
            </div>
            <div>
                <UserPosts />
            </div>
            <div>
                <Footer />
            </div>
        </>
    );
};

export default App;

