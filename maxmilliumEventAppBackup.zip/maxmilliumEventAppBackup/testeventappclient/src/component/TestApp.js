import React, { useState } from 'react';
import { BrowserRouter, Route, Redirect, Switch } from 'react-router-dom';
import UserAuthPage from '../testPages/UserAuth';
import BookingsPage from '../testPages/Bookings';
import EventsPage from '../testPages/Events';
import MainNavigation from './TestNavigation/TestMainNavigation';
import './TestApp.css';
import AuthContext from '../TestContext/auth-context';

const TestApp = () => {
    const [state, actionOnState] = useState({
        token: null,
        userId: null
    });
    const login = (token, userId, tokenExpiration) => {
        actionOnState({
            token: token,
            userId: userId
        });
    };
    const logout = () => {
        actionOnState({
            token: null,
            userId: null
        });
    };
    return (
        <h1>
            <BrowserRouter>
                <>
                    <AuthContext.Provider value={{
                        token: state.token,
                        userId: state.userId,
                        login: login,
                        logout: logout
                    }}>
                        <MainNavigation />
                        <main className="main-content">
                            <Switch>
                                {state.token && <Redirect from="/" to="/events" exact />}
                                {state.token && <Redirect from="/auth" to="/events" exact />}
                                {!state.token && (
                                    <Route path="/auth" component={UserAuthPage} />
                                )}
                                <Route path="/events" component={EventsPage} />
                                {state.token && (
                                    <Route path="/bookings" component={BookingsPage} />
                                )}
                                {!state.token && <Redirect to="/auth" exact />}
                            </Switch>
                        </main>
                    </AuthContext.Provider>
                </>
            </BrowserRouter>
        </h1>
    );
};

export default TestApp;
