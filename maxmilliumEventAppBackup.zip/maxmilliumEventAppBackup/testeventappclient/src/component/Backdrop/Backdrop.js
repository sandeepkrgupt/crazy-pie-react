import React from 'react';
//import './Backdrop.css';
const Backdrop = () => <div className="backdrop"/>;
export default Backdrop;
