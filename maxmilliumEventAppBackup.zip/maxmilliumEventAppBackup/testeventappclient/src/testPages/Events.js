import React, { Component } from 'react';
import './Events.css';
import Modal from '../component/Modal/Modal';
import Backdrop from '../component/Backdrop/Backdrop';

class EventsPage extends Component {
    render () {
        return (
            <>
                <Backdrop />
                <Modal title="Add Event" canCancel canConfirm>
                    <p>Modal Content</p>
                </Modal>
                <div className="events-control">
                    <p>Share your Events</p>
                    <button onClick={null}>create Events</button>
                </div>
            </>
        );
    }
}
export default EventsPage;
