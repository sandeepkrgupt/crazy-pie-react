const bcrypt = require('bcryptjs');

const User = require('../../models/user');
const jwt = require('jsonwebtoken');

module.exports = {
    createUser: async args => {
        try {
            const existingUser = await User.findOne({ email: args.userInput.email })
            if (existingUser) {
                throw new Error('User Already Exist');
            };
            const hashedPassword = await bcrypt.hash(args.userInput.password, 12);
            const user = new User({
                email: args.userInput.email,
                password: hashedPassword
            })
            const result = await user.save();
            return {
                ...result._doc,
                password: null,
                _id: result.id
            }
        } catch (err) {
            throw err;
        }
    },
    login: async ({ email, password}) => {
        const testUser = await User.findOne({ email: email });
        if(!testUser) {
            throw new Error('User Doesnot exists');
        };
        const isEqual = await bcrypt.compare(password, testUser.password);
        if(!isEqual) {
            throw new Error('Password is Incorrect!');
        };
        const token = jwt.sign({ userId: testUser.id, email: testUser.email }, 'somesupersecretkey', {
            expiresIn: '1h'
        });
        return { userId: testUser.id, token: token, tokenExpiration: 1 }
    }
}