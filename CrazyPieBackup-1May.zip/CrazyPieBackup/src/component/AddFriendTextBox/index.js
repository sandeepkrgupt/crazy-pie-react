import React from 'react';
import { Select, Tag } from 'antd';

const options = [
    { value: 'Apple' },
    { value: 'Banana' },
    { value: 'Mango' },
    { value: 'Kiwi' }
];

function tagRender (props) {
    const { value, closable, onClose } = props;
    return (
        <Tag
            closable={closable}
            onClose={onClose}
            style={{ marginRight: 3 }}
        >
            {value}
        </Tag>
    );
}
const AddFriendAutocompleteTextBox = () => {
    return (
        <Select
            mode="multiple"
            tagRender={tagRender}
            defaultValue={[]}
            style={{ width: '100%' }}
            options={options}
        />
    );
};
export default AddFriendAutocompleteTextBox;

