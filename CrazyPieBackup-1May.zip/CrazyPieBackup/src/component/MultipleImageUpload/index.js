import React, { useState } from 'react';
import { Upload, Modal, message } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { getBase64ForMultipleImageUpload } from '../../utils';

const MultipleImageUploader = () => {
    const [
        state = {
            previewVisible: false,
            previewImage: '',
            previewTitle: '',
            fileList: [],
        },
        setState
    ] = useState();

    const handleCancel = () => setState({ previewVisible: false });

    const handlePreview = async file => {
        console.log('-', file);
        if (!file.url && !file.preview) {
            file.preview = await getBase64ForMultipleImageUpload(file.originFileObj);
        }

        setState({
            previewImage: file.url || file.preview,
            previewVisible: true,
            previewTitle: file.name || file.url.substring(file.url.lastIndexOf('/') + 1)
        });
    };

    const handleChange = ({ file, fileList }) => {
        const isJpgOrPng = file.type === 'image/jpeg' || file.type === 'image/png';
        const isLt2M = file.size / 1024 / 1024 < 2;
        if (isJpgOrPng && isLt2M) {
            console.log('=', fileList);
            setState({ fileList });
        } else {
            message.error('You can only upload JPG/PNG file! of 2MB');
        }
    };

    const { previewVisible, previewImage, fileList, previewTitle } = state;
    const uploadButton = (
        <div>
            <PlusOutlined />
            <div className="ant-upload-text">Upload Image</div>
        </div>
    );
    return (
        <div className="clearfix">
            <Upload
                action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                listType="picture-card"
                fileList={fileList}
                onPreview={handlePreview}
                onChange={handleChange}
            >
                {fileList.length > 3 ? null : uploadButton}
            </Upload>
            <Modal
                visible={previewVisible}
                title={previewTitle}
                footer={null}
                onCancel={handleCancel}
            >
                <img alt="example" style={{ width: '100%' }} src={previewImage} />
            </Modal>
        </div>
    );
};

export default MultipleImageUploader;
