import React from 'react';
import { Select } from 'antd';

const { Option } = Select;

const onChange = (value) => {
    console.log(`selected ${value}`);
};

const onBlur = () => {
    console.log('blur');
};

const onFocus = () => {
    console.log('focus');
};

const onSearch = (val) => {
    console.log('search:', val);
};
let selectOptions = [{
    id: 1,
    value: 'Chess'
}, {
    id: 2,
    value: 'Cricket'
}, {
    id: 3,
    value: 'Dance'
}];
const AutoCompleteSelectResult = () => {
    return (
        <Select
            showSearch
            //loading="true"
            placeholder="Select a person"
            optionFilterProp="children"
            onChange={(e) => onChange(e)}
            onFocus={() => onFocus()}
            onBlur={() => onBlur()}
            onSearch={() => onSearch()}
            filterOption={(input, option) =>
                option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
            }
        >
            {selectOptions.map((p) => <Option key={p.id} value={p.value}>{p.value}</Option>)}
        </Select>
    );
};

export default AutoCompleteSelectResult;

