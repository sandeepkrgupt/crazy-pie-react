import React from 'react';
import Header from '../component/Header';
//import ActivityBox from './ActivityBox';
import Footer from './Footer';
import { Row, Col } from 'antd';
// import UserPosts from './SearchResult';
// import UserSuggestionBox from './UserSuggestionBox';
// import SignUp from './SignUp';
// import LogIn from './Login';
// import ActivityBox from './ActivityBox';
import mockData from '../../public/mockData.json';
// import MyProfile from './MyProfile';
// import UserProfile from './UserProfile';
// import Chat from './Chat';
import CreateEvent from './CreateEvent';
//import CreateGroup from './CreateGroup';
//import SimpleSlider from './Carousel/test';
const App = () => {
    const userData = mockData;
    return (
        <>
            <Header details={userData} />
            <section>
                <Row>
                    <Col span={2} />
                    <Col span={20}>
                        {
                            userData === null ?
                                (
                                    <div className="site-content-area" />
                                ) :
                                (
                                    <>
                                        {/* <div>
                                            <SignUp />
                                        </div>
                                        <div>
                                            <LogIn />
                                        </div>
                                        <div>
                                            <ActivityBox />
                                        </div>
                                        <div>
                                            <UserSuggestionBox details={userData} />
                                            <hr />
                                            <UserPosts details={userData} />
                                        </div>
                                        <div>
                                            <MyProfile />
                                        </div>
                                        <div>
                                            <UserProfile />
                                        </div>
                                        <div>
                                            <Chat />
                                        </div>
                                        <div>
                                            <CreateEvent />
                                        </div>
                                        <div>
                                            <CreateGroup />
                                        </div> */}
                                        <div>
                                            <CreateEvent />
                                        </div>
                                    </>
                                )
                        }
                        <Footer />
                    </Col>
                    <Col span={2} />
                </Row>
            </section>
        </>
    );
};

export default App;

