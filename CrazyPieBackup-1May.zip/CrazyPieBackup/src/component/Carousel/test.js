import React from "react";
import Slider from "react-slick";
//import UserSuggestionCard from '../UserSuggestionCard';
import { Card } from 'antd';

const { Meta } = Card;
const SimpleSlider = (props) => {
    const {
        alt,
        src,
        title,
        description
    } = props;
    var settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 3,
        slidesToScroll: 2
    };

    return (
        <Slider {...settings}>
            <div>
                <Card className="user-suggestion-cards"
                    hoverable
                    style={{ width: '12vw', margin: '2%' }}
                    cover={<img alt={alt} src={src} />}
                >
                    one
                    <Meta title={title} description={description} />
                </Card>
            </div>
            <div>
                <Card className="user-suggestion-cards"
                    hoverable
                    style={{ width: '12vw', margin: '2%' }}
                    cover={<img alt={alt} src={src} />}
                >
                    two
                    <Meta title={title} description={description} />
                </Card>
            </div>
            <div>
                <Card className="user-suggestion-cards"
                    hoverable
                    style={{ width: '12vw', margin: '2%' }}
                    cover={<img alt={alt} src={src} />}
                >
                    three
                    <Meta title={title} description={description} />
                </Card>
            </div>
            <div>
                <Card className="user-suggestion-cards"
                    hoverable
                    style={{ width: '12vw', margin: '2%' }}
                    cover={<img alt={alt} src={src} />}
                >
                    four
                    <Meta title={title} description={description} />
                </Card>
            </div>
            <div>
                <Card className="user-suggestion-cards"
                    hoverable
                    style={{ width: '12vw', margin: '2%' }}
                    cover={<img alt={alt} src={src} />}
                >
                    five
                    <Meta title={title} description={description} />
                </Card>
            </div>
        </Slider>
    );
};
export default SimpleSlider;
