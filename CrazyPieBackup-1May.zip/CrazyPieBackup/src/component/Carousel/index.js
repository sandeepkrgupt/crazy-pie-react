import React from 'react';
import { Carousel } from 'antd';

function onChange (a, b, c) {
    console.log('->>>>', a, b, c);
}

const UserCarousel = () => {
    return (
        <Carousel afterChange={onChange}>
            <div>
                <img src="https://www.dawsons.co.uk/blog/wp-content/uploads/2015/06/Playing-Guitar.jpg" />
            </div>
            <div>
                <img src="https://cdn.mos.cms.futurecdn.net/3z2jp4Hurn4Ak4TAXWgyj6-1200-80.jpg" />
            </div>
            <div>
                <img src="https://www.dawsons.co.uk/blog/wp-content/uploads/2015/06/Playing-Guitar.jpg" />
            </div>
        </Carousel>
    );
};

export default UserCarousel;
